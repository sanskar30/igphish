<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Asia Panel">
    <meta name="author" content="MasterOgar RENDY">
    <link href="assets/images/favicon/favicon.png" rel="icon" type="image/x-icon" />
    <title>Asia Panel</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/main-style.css" rel="stylesheet">
    <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <style>
        body {
            padding-top: 100px;
            background-image: url("assets/images/slide_01.jpg");
        }
    </style>
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="backcuk">
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
         <a href="index.php" class="navbar-brand">Asia Panel</a>        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="Dashboard" onclick="this.href = 'index.php'"><i class="glyphicon glyphicon-home"></i> Dashboard</a></li>
            <li class="active"><a href="Rules" onclick="this.href = 'peraturan.php'"><i class="fa fa-info-circle"></i> Rules</a></li>
            <li><a href="Contact Me" onclick="this.href = 'kontak.php'"><i class="glyphicon glyphicon-earphone"></i> Contact Me</a></li>
            <li><a href="Log In" onclick="this.href = 'masuk.php'"><i class="glyphicon glyphicon-off"></i> Log In</a></li>          </ul>
          </div>
      </div>
    </nav>
    <div class="container">
        <div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
            <div class="panel panel-info" >
                    <div class="panel-heading">
                        <div class="panel-title">Rules and Use of Services</div>
                    </div> 
                    <div class="panel-body">
                        <h2 class="text-center">RULES</h2><hr>
                                        <ol>
                                            <li>
                                                Do not Unfollow Fellow Users of this Service. Simply Msntion them Yo Follback.
                                            </li>
                                            <li>
                                                Do not Private your Account, If you re Private your ccount, Followers will not Increase.
                                            </li>
                                            <li>
                                                This Service is Free, Please use This Service Wisely
                                            </li>
                                            <li>
                                                Use this tools at your Own Risk
                                            </li>
                                            <li>
                                                Remember We Never Save your Password! We just Need your Password at Login to Connect your Account With Asia Panel.
                                            </li>
                                        </ol><hr>
                        <h2 class="text-center">HELP</h2><hr>
                                        <ol>
                                            <li>
                                                <h4>How To Stop From This Service?</h4>
                                                <p>Simply Change your Instagram Password, and You Stop Automatically From this Service</p>
                                            </li>
                                            <li>
                                                <h4>Why Following I Increase?</h4>
                                                <p>Because These Services are Exchange Followers. You get Followers you Also get Following. You can Mention them To do Follback</p>
                                            </li>
                                            <li>
                                                <h4>I Want to Give Feedback to Yhis Service, Where Should I Send it?</h4>
                                                <p>Please click 'Contact Me' Menu Above. Thank you</p>
                                            </li>
                                        </ol><hr>
                    </div>
                </div>
            </div>
        </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html> 